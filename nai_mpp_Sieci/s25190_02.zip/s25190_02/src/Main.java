import java.util.Scanner;

public class Main {
    public static void main(String[] args) {


        //start(4, new int[][]{{'a', 3}, {'b', 6}, {'c', 22}, {'d', 31},}, new int[]{2}, new int[]{3});
        start(2, new int[][]{{'a', 34}, {'b', 38},{'a',35},{'b',38},{'b',39},{'a',37},{'b',39},{'a',34} }, new int[]{6,3}, new int[]{38,39});
        //start();

    }

    public static void start() {
        Plansza plansza = new Plansza(4);
        gra(plansza);
    }

    public static void start(int liczbagraczy, int[][] pionkiNaPlanszy, int[] tabelawynikow, int[] tabeladecyzji) {
        Plansza plansza = new Plansza(liczbagraczy);
        rozegraj(pionkiNaPlanszy, tabelawynikow, tabeladecyzji, plansza);
        gra(plansza, tabeladecyzji.length % liczbagraczy);

    }

    public static int rzutkostka() {

        return (int) ((Math.random() * 6) + 1);

    }

    public static void rozegraj(int[][] pionkiNaPlanszy, int[] tabelawynikow, int[] tabeladecyzji, Plansza plansza) {
        for (int i = 0; i < pionkiNaPlanszy.length; i++) {
            plansza.ustawpionekforced(pionkiNaPlanszy[i][0] - 'a', pionkiNaPlanszy[i][1]);
        }
        for (int i = 0; i < tabelawynikow.length; i++) {
            plansza.przesunPionek(plansza.pola[tabeladecyzji[i]].pionki[0].kolor - 'a', tabeladecyzji[i], tabelawynikow[i]);
        }

    }

    public static void gra(Plansza plansza, int poczatkowygracz) {
        boolean run = true;
        int counter = poczatkowygracz % plansza.liczbaGraczy;
        Scanner scanner = new Scanner(System.in);
        while (run) {
            //System.out.println(plansza.schowki[counter].counter+" "+plansza.domki[counter].counter);
            int rzut;
            do {
                plansza.odswiezyc();
                plansza.showplansza();

                rzut = 6;


                System.out.println("Tura gracza: " + (char) ('a' + counter));
                System.out.println("Wylosowano: " + rzut);
                System.out.println("Aby pominąc turę wpisz(0)");
                if (plansza.schowki[counter].counter > 0 && rzut == 6) {
                    System.out.println("Czy chcesz wyciągnąć pionka? wpisz(1) ");

                }
                if (4 - plansza.domki[counter].counter - plansza.schowki[counter].counter > 0) {
                    System.out.println("Czy wolisz się ruszyć pionkiem? wpisz(2)");
                }
                for (int i = 0; i < plansza.domki.length; i++) {
                    //System.out.println(plansza.domki[i].counter);
                    if (plansza.domki[i].counter == 4) {
                        System.out.println("wygrał gracz o pionkach " + (char) (('a' + i)));
                        run = false;
                        rzut=1;
                    }
                }
                int wybor = scanner.nextInt();
                if (wybor == 1 && plansza.schowki[counter].counter > 0 && rzut == 6) {
                    plansza.wyjdzZeSchowka(counter);

                } else if (wybor == 2) {
                    System.out.println("Podaj nr pola z którego chcesz ruszyć pionkiem ");

                    plansza.przesunPionek(counter, scanner.nextInt(), rzut);
                } else if (wybor == 0) {
                    System.out.println("Pominieto ture ");

                }




            } while (rzut == 6);


            counter++;
            if (counter > plansza.liczbaGraczy - 1) counter = 0;
        }
    }

    public static void gra(Plansza plansza) {
        boolean run = true;
        int counter = (int) (Math.random() * 100%plansza.liczbaGraczy);
        Scanner scanner = new Scanner(System.in);
        boolean first = true;
        while (run) {
            //System.out.println(plansza.schowki[counter].counter+" "+plansza.domki[counter].counter);
            int rzut;
            do {
                plansza.odswiezyc();
                plansza.showplansza();

                rzut = rzutkostka();
                if (first) {
                    rzut = 6;
                    first = false;
                }
                System.out.println("Tura gracza: " + (char) ('a' + counter));
                System.out.println("Wylosowano: " + rzut);
                System.out.println("Aby pominąc turę wpisz(0)");
                if (plansza.schowki[counter].counter > 0 && rzut == 6) {
                    System.out.println("Czy chcesz wyciągnąć pionka? wpisz(1) ");

                }
                if (4 - plansza.domki[counter].counter - plansza.schowki[counter].counter > 0) {
                    System.out.println("Czy wolisz się ruszyć pionkiem? wpisz(2)");
                }
                int wybor = scanner.nextInt();
                if (wybor == 1 && plansza.schowki[counter].counter > 0 && rzut == 6) {
                    plansza.wyjdzZeSchowka(counter);

                } else if (wybor == 2) {
                    System.out.println("Podaj nr pola z którego chcesz ruszyć pionkiem ");

                    plansza.przesunPionek(counter, scanner.nextInt(), rzut);
                } else if (wybor == 0) {
                    System.out.println("Pominieto ture ");

                }


            } while (rzut == 6);

            for (int i = 0; i < plansza.domki.length; i++) {
                if (plansza.domki[i].counter == 4) {
                    System.out.println("wygrał gracz o pionkach " + (char) (('a' + i)));
                    run = false;
                }
            }
            counter++;
            if (counter > plansza.liczbaGraczy - 1) counter = 0;
        }

    }

}

class Pole {
    Pionek[] pionki = new Pionek[16];

    int counter = 0;

    public char getPole() {
        if (counter == 0) {
            return 'x';
        }

        return pionki[0].kolor;
    }


    public void postawPionka(Pionek pionek) {
        pionki[counter] = pionek;
        counter++;
    }

}

class Pionek {
    char kolor;

    int podroz = 0;

    public Pionek(char kolor) {
        this.kolor = kolor;
    }
}

class Plansza {
    Pole[] pola = new Pole[40];

    int liczbaGraczy;
    Schowek[] schowki;
    Domek[] domki;

    public void ustawpionekforced(int gracz, int pole) {
        wyjdzZeSchowka(gracz);
        Pole p = pola[gracz * 10];
        Pionek[] pioneksy = p.pionki;

        Pionek pionek = null;
        int index = 0;
        for (int i = 0; i < p.counter; i++) {
            if (pioneksy[i].kolor == (char) ('a' + gracz)) {
                pionek = pioneksy[i];
                index = i;
            }
        }
        p.counter--;
        Pionek[] pionkiNaPolu = new Pionek[16];
        for (int i = 0; i < pionkiNaPolu.length; i++) {
            if (i < index) {
                pionkiNaPolu[i] = pioneksy[i];
            }
            if (i > index) {
                pionkiNaPolu[i - 1] = pioneksy[i];
            }
        }
        p.pionki = pionkiNaPolu;
        pola[(pole) % 40].pionki[pola[(pole) % 40].counter] = pionek;
        pola[(pole) % 40].counter++;
        if (pole > 10 * p.counter) {
            pionek.podroz = pole - 10 * p.counter;
        } else {
            pionek.podroz = 40 - 10 * p.counter + pole;
        }
    }

    static final int[][][] wspolrzedneDomkow = {
            {{2, 12}, {3, 12}, {4, 12}, {5, 12}},
            {{6, 20}, {6, 18}, {6, 16}, {6, 14}},
            {{10, 12}, {9, 12}, {8, 12}, {7, 12}},
            {{6, 4}, {6, 6}, {6, 8}, {6, 10}}
    };
    static final int[][][] wspolrzedneShowkow = {
            {{1, 20}, {1, 22}, {2, 20}, {2, 22}},
            {{11, 20}, {11, 22}, {10, 20}, {10, 22}},
            {{10, 2}, {10, 4}, {11, 2}, {11, 4}},
            {{1, 2}, {1, 4}, {2, 2}, {2, 4}}
    };

    public Plansza(int liczbaGraczy) {
        this.liczbaGraczy = liczbaGraczy;
        schowki = new Schowek[liczbaGraczy];
        domki = new Domek[liczbaGraczy];
        for (int i = 0; i < wyglad.length; i++) {
            for (int i1 = 0; i1 < wyglad[i].length; i1++) {
                wyglad[i][i1] = ' ';
            }
        }
        for (int i = 0; i < pola.length; i++) {
            Pole pole = new Pole();
            pola[i] = pole;
        }
        wyglad[0][14] = '0';
        wyglad[7][23] = '1';
        wyglad[7][24] = '0';
        wyglad[12][10] = '2';
        wyglad[12][11] = '0';
        wyglad[5][0] = '3';
        wyglad[5][1] = '0';
        for (int i = 0; i < liczbaGraczy; i++) {
            schowki[i] = new Schowek((char) ('a' + i));
        }
        for (int i = 0; i < liczbaGraczy; i++) {
            domki[i] = new Domek();
        }

    }

    char[][] wyglad = new char[13][25];
    static final int[][] wspolrzedne = {
            {1, 14}, {2, 14}, {3, 14}, {4, 14}, {5, 14},//0 w doł
            {5, 16}, {5, 18}, {5, 20}, {5, 22},// w prawo
            {6, 22}, {7, 22},// w dol
            {7, 20}, {7, 18}, {7, 16}, {7, 14},//w lewo
            {8, 14}, {9, 14}, {10, 14}, {11, 14},//w dol
            {11, 12}, {11, 10},//w lewo
            {10, 10}, {9, 10}, {8, 10}, {7, 10},//w gore
            {7, 8}, {7, 6}, {7, 4}, {7, 2},//w lewo
            {6, 2}, {5, 2},//w gore
            {5, 4}, {5, 6}, {5, 8}, {5, 10},//w prawo
            {4, 10}, {3, 10}, {2, 10}, {1, 10},//w gore
            {1, 12}//w prawo

    };

    public void odswiezyc() {
        for (int i = 0; i < wyglad.length; i++) {
            for (int i1 = 0; i1 < wyglad[i].length; i1++) {
                wyglad[i][i1] = ' ';
            }
        }

        wyglad[0][14] = '0';
        wyglad[7][23] = '1';
        wyglad[7][24] = '0';
        wyglad[12][10] = '2';
        wyglad[12][11] = '0';
        wyglad[5][0] = '3';
        wyglad[5][1] = '0';
        for (int i = 0; i < wspolrzedne.length; i++) {
            wyglad[wspolrzedne[i][0]][wspolrzedne[i][1]] = pola[i].getPole();
        }
        System.out.println();
        for (int i = 0; i < liczbaGraczy; i++) {
            for (int j = 0; j < schowki[i].counter; j++) {
                wyglad[wspolrzedneShowkow[i][j][0]][wspolrzedneShowkow[i][j][1]] = (char) ('a' + i);
            }
        }
        for (int i = 0; i < liczbaGraczy; i++) {
            for (int j = 0; j < domki[i].counter; j++) {
                wyglad[wspolrzedneDomkow[i][j][0]][wspolrzedneDomkow[i][j][1]] = (char) ('a' + i);
            }
        }
    }

    public void showplansza() {
        for (char[] chars : wyglad) {
            for (char aChar : chars) {
                System.out.print(aChar);
            }
            System.out.println();
        }
    }

    public void wyjdzZeSchowka(int gracz) {
        pola[10 * gracz].postawPionka(schowki[gracz].pionki[schowki[gracz].counter - 1]);
        schowki[gracz].counter--;
    }

    public void przesunPionek(int gracz, int pole, int rzutkostka) {
        Pole p = pola[pole];
        Pionek[] pioneksy = p.pionki;

        Pionek pionek = null;
        int index = 0;
        for (int i = 0; i < p.counter; i++) {
            if (pioneksy[i].kolor == (char) ('a' + gracz)) {
                pionek = pioneksy[i];
                index = i;
            }
        }
        p.counter--;
        Pionek[] pionkiNaPolu = new Pionek[16];
        for (int i = 0; i < pionkiNaPolu.length; i++) {
            if (i < index) {
                pionkiNaPolu[i] = pioneksy[i];
            }
            if (i > index) {
                pionkiNaPolu[i - 1] = pioneksy[i];
            }
        }
        p.pionki = pionkiNaPolu;
        pionek.podroz += rzutkostka;
        if (pionek.podroz > 40) {
            domki[gracz].counter++;
        } else {
            pola[(pole + rzutkostka) % 40].pionki[pola[(pole + rzutkostka) % 40].counter] = pionek;
            pola[(pole + rzutkostka) % 40].counter++;

        }


    }


}

class Schowek {
    int counter = 4;
    Pionek[] pionki = new Pionek[4];
    char kolor;

    public Schowek(char kolor) {
        this.kolor = kolor;
        for (int i = 0; i < pionki.length; i++) {
            pionki[i] = new Pionek(kolor);
        }
    }
}

class Domek {
    int counter = 0;
    char kolor;


}